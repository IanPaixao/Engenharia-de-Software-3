//------------------------------------------------------------------------------
// Copyright (c) 2005, 2006 IBM Corporation and others.
// All rights reserved. This program and the accompanying materials
// are made available under the terms of the Eclipse Public License v1.0
// which accompanies this distribution, and is available at
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contributors:
// IBM Corporation - initial implementation
//------------------------------------------------------------------------------

// This file will include dynamically generated process layout related data from 
// the publishing service 
contentPage.processPage.imageFiles["_5zo6ge36Eei8U5RcoL9UmgActivity"]="./../../PluginVAL-VER/deliveryprocesses/resources/DeliveryVAL-VER_1EF097F_1ef097f_Activity.jpeg"
contentPage.processPage.imageFiles["_5zo6ge36Eei8U5RcoL9Umg,_NUgH4e5EEei8U5RcoL9UmgActivityDetail"]="./../../PluginVAL-VER/deliveryprocesses/resources/VAL2_69BDDD5B_e59ca82e_ActivityDetail.jpeg"
contentPage.processPage.imageFiles["_5zo6ge36Eei8U5RcoL9Umg,_WB-1Ye5EEei8U5RcoL9UmgActivityDetail"]="./../../PluginVAL-VER/deliveryprocesses/resources/VER4_A93388FD_251253d0_ActivityDetail.jpeg"
contentPage.processPage.imageFiles["_5zo6ge36Eei8U5RcoL9Umg,_Ujdo8e5EEei8U5RcoL9UmgActivityDetail"]="./../../PluginVAL-VER/deliveryprocesses/resources/VER2_D049050F_4c27cfe2_ActivityDetail.jpeg"
contentPage.processPage.imageFiles["_5zo6ge36Eei8U5RcoL9Umg,_QeILQe5EEei8U5RcoL9UmgActivityDetail"]="./../../PluginVAL-VER/deliveryprocesses/resources/VAL3_1D176AAD_98f63580_ActivityDetail.jpeg"
contentPage.processPage.imageFiles["_5zo6ge36Eei8U5RcoL9Umg,_VUfdQe5EEei8U5RcoL9UmgActivityDetail"]="./../../PluginVAL-VER/deliveryprocesses/resources/VER3_79732A93_f551f566_ActivityDetail.jpeg"
contentPage.processPage.imageFiles["_5zo6ge36Eei8U5RcoL9Umg,_IIeSEe37Eei8U5RcoL9UmgActivity"]="./../../PluginVAL-VER/deliveryprocesses/resources/VAL_9990B584_156f8057_Activity.jpeg"
contentPage.processPage.imageFiles["_5zo6ge36Eei8U5RcoL9Umg,_IIeSEe37Eei8U5RcoL9UmgActivityDetail"]="./../../PluginVAL-VER/deliveryprocesses/resources/VAL_9990B584_156f8057_ActivityDetail.jpeg"
contentPage.processPage.imageFiles["_5zo6ge36Eei8U5RcoL9Umg,_IIeSEe37Eei8U5RcoL9UmgWPDependency"]="./../../PluginVAL-VER/deliveryprocesses/resources/VAL_9990B584_156f8057_WPDependency.jpeg"
contentPage.processPage.imageFiles["_5zo6ge36Eei8U5RcoL9Umg,_SowPwe5EEei8U5RcoL9UmgActivityDetail"]="./../../PluginVAL-VER/deliveryprocesses/resources/VAL5_AB8213A5_2760de78_ActivityDetail.jpeg"
contentPage.processPage.imageFiles["_5zo6ge36Eei8U5RcoL9Umg,_9Vkwke5EEei8U5RcoL9UmgActivityDetail"]="./../../PluginVAL-VER/deliveryprocesses/resources/VE_9856465_85642f38_ActivityDetail.jpeg"
contentPage.processPage.imageFiles["_5zo6ge36Eei8U5RcoL9Umg,_LEZ3se37Eei8U5RcoL9UmgActivityDetail"]="./../../PluginVAL-VER/deliveryprocesses/resources/VER_A3B442BA_1f930d8d_ActivityDetail.jpeg"
contentPage.processPage.elementUrls["_lmXo8O5HEei8U5RcoL9Umg"] = ["Resultados de atividades","PluginVAL-VER/deliveryprocesses/resultados_de_atividades_4F7AC814.html"];
contentPage.processPage.elementUrls["_piRd0u5HEei8U5RcoL9Umg"] = ["Cronograma para as atividades de verificação","PluginVAL-VER/deliveryprocesses/cronograma_para_as_atividades_de_verificacao_C7B88635.html"];
contentPage.processPage.elementUrls["_VUfdQe5EEei8U5RcoL9Umg"] = ["VER3","PluginVAL-VER/deliveryprocesses/VER3_79732A93.html"];
contentPage.processPage.elementUrls["_IIeSEe37Eei8U5RcoL9Umg"] = ["VAL1","PluginVAL-VER/deliveryprocesses/VAL_9990B584.html"];
contentPage.processPage.elementUrls["_to4t4O5HEei8U5RcoL9Umg"] = ["Estratégia de validação","PluginVAL-VER/deliveryprocesses/estrategia_de_validacao_FC24C2FB.html"];
contentPage.processPage.elementUrls["_uYwroO5HEei8U5RcoL9Umg"] = ["Produtos de trabalho a serem validados são identificados","PluginVAL-VER/deliveryprocesses/produtos_de_trabalho_a_serem_validados_sao_identificados_BF2AD904.html"];
contentPage.processPage.elementUrls["_WB-1Ye5EEei8U5RcoL9Umg"] = ["VER4","PluginVAL-VER/deliveryprocesses/VER4_A93388FD.html"];
contentPage.processPage.elementUrls["_oAzrEe5HEei8U5RcoL9Umg"] = ["Tester","PluginVAL-VER/deliveryprocesses/tester_CF40F34F.html"];
contentPage.processPage.elementUrls["_sabWs-5HEei8U5RcoL9Umg"] = ["Relatórios de testes e registro dos erros","PluginVAL-VER/deliveryprocesses/relatorios_de_testes_e_registro_dos_erros_C1603702.html"];
contentPage.processPage.elementUrls["_piHs0O5HEei8U5RcoL9Umg"] = ["Estratégia de verificação","PluginVAL-VER/deliveryprocesses/estrategia_de_verificacao_CF2AECA8.html"];
contentPage.processPage.elementUrls["_oAzrEO5HEei8U5RcoL9Umg"] = ["Atividades de verificação","PluginVAL-VER/deliveryprocesses/atividades_de_verificacao_E0A7DF39.html"];
contentPage.processPage.elementUrls["_QeILQe5EEei8U5RcoL9Umg"] = ["VAL3","PluginVAL-VER/deliveryprocesses/VAL3_1D176AAD.html"];
contentPage.processPage.elementUrls["_qWH8oO5HEei8U5RcoL9Umg"] = ["Produtos de trabalho a serem verificados são identificados","PluginVAL-VER/deliveryprocesses/produtos_de_trabalho_a_serem_verificados_sao_identificados_6C91825B.html"];
contentPage.processPage.elementUrls["_9Vkwke5EEei8U5RcoL9Umg"] = ["VER6","PluginVAL-VER/deliveryprocesses/VE_9856465.html"];
contentPage.processPage.elementUrls["_qWH8oe5HEei8U5RcoL9Umg"] = ["Gerente de Testes","PluginVAL-VER/deliveryprocesses/gerente_de_testes_5B2A9671.html"];
contentPage.processPage.elementUrls["_LEZ3se37Eei8U5RcoL9Umg"] = ["VER1","PluginVAL-VER/deliveryprocesses/VER_A3B442BA.html"];
contentPage.processPage.elementUrls["_sabWse5HEei8U5RcoL9Umg"] = ["Analista de Testes","PluginVAL-VER/deliveryprocesses/analista_de_testes_6688C73A.html"];
contentPage.processPage.elementUrls["_SowPwe5EEei8U5RcoL9Umg"] = ["VAL6","PluginVAL-VER/deliveryprocesses/VAL5_AB8213A5.html"];
contentPage.processPage.elementUrls["_uYwro-5HEei8U5RcoL9Umg"] = ["Lista de produtos","PluginVAL-VER/deliveryprocesses/lista_de_produtos_89B5CE2.html"];
contentPage.processPage.elementUrls["_lmXo8-5HEei8U5RcoL9Umg"] = ["Laudos de avaliação e relatórios de testes","PluginVAL-VER/deliveryprocesses/laudos_de_avalicacao_e_relatorios_de_testes_98EB4BF2.html"];
contentPage.processPage.elementUrls["_oAzrE-5HEei8U5RcoL9Umg"] = ["planejamento dos testes","PluginVAL-VER/deliveryprocesses/planejamento_dos_testes_2A186317.html"];
contentPage.processPage.elementUrls["_oAzrFe5HEei8U5RcoL9Umg"] = ["Relatórios dos testes","PluginVAL-VER/deliveryprocesses/relatorios_dos_testes_93D2D56E.html"];
contentPage.processPage.elementUrls["_sabWsO5HEei8U5RcoL9Umg"] = ["Resultados de atividades de validação","PluginVAL-VER/deliveryprocesses/resultados_de_atividades_de_validacao_77EFB324.html"];
contentPage.processPage.elementUrls["_lmXo8e5HEei8U5RcoL9Umg"] = ["Gerente de Testes","PluginVAL-VER/deliveryprocesses/gerente_de_testes_3E13DC2A.html"];
contentPage.processPage.elementUrls["_to4t4e5HEei8U5RcoL9Umg"] = ["Gerente de Testes","PluginVAL-VER/deliveryprocesses/gerente_de_testes_EABDD711.html"];
contentPage.processPage.elementUrls["_o3y9cO5HEei8U5RcoL9Umg"] = ["Critérios e procedimentos para verificação","PluginVAL-VER/deliveryprocesses/criterios_e_procedimentos_para_verificacao_86D15775.html"];
contentPage.processPage.elementUrls["_o38HYO5HEei8U5RcoL9Umg"] = ["questões (checklist) e/ou métricas para cada critério","PluginVAL-VER/deliveryprocesses/questoes_checklist_eou_metricas_para_cada_criterio_1602CE6F.html"];
contentPage.processPage.elementUrls["_5zo6ge36Eei8U5RcoL9Umg"] = ["Delivery: Validação e Verificação","PluginVAL-VER/deliveryprocesses/DeliveryVAL-VER_1EF097F.html"];
contentPage.processPage.elementUrls["_piRd1O5HEei8U5RcoL9Umg"] = ["planejamento dos testes","PluginVAL-VER/deliveryprocesses/planejamento_dos_testes_9313742E.html"];
contentPage.processPage.elementUrls["_tGw4Q-5HEei8U5RcoL9Umg"] = ["Ferramentas de apoio","PluginVAL-VER/deliveryprocesses/ferramentas_de_apoio_C6F832D1.html"];
contentPage.processPage.elementUrls["_piRd1u5HEei8U5RcoL9Umg"] = ["plano do projeto","PluginVAL-VER/deliveryprocesses/plano_do_projeto_8C4A6854.html"];
contentPage.processPage.elementUrls["_o3y9ce5HEei8U5RcoL9Umg"] = ["Analista de Testes","PluginVAL-VER/deliveryprocesses/analista_de_testes_756A6B8B.html"];
contentPage.processPage.elementUrls["_Ujdo8e5EEei8U5RcoL9Umg"] = ["VER2","PluginVAL-VER/deliveryprocesses/VER2_D049050F.html"];
contentPage.processPage.elementUrls["_NUgH4e5EEei8U5RcoL9Umg"] = ["VAL2","PluginVAL-VER/deliveryprocesses/VAL2_69BDDD5B.html"];
contentPage.processPage.elementUrls["_uYwroe5HEei8U5RcoL9Umg"] = ["Gerente de Testes","PluginVAL-VER/deliveryprocesses/gerente_de_testes_ADC3ED1A.html"];
contentPage.processPage.elementUrls["_piRd0O5HEei8U5RcoL9Umg"] = ["Gerente de Testes","PluginVAL-VER/deliveryprocesses/gerente_de_testes_CE81920F.html"];
contentPage.processPage.elementUrls["_o38HYu5HEei8U5RcoL9Umg"] = ["Relatórios técnicos","PluginVAL-VER/deliveryprocesses/relatorios_tecnicos_F39C295.html"];
contentPage.processPage.elementUrls["_tGw4Qe5HEei8U5RcoL9Umg"] = ["Analista de Testes","PluginVAL-VER/deliveryprocesses/analista_de_testes_6C20C309.html"];
contentPage.processPage.elementUrls["_tGw4QO5HEei8U5RcoL9Umg"] = ["Critérios e procedimentos para validação","PluginVAL-VER/deliveryprocesses/criterios_e_procedimentos_para_validacao_7D87AEF3.html"];
