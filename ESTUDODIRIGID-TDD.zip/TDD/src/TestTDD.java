import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


class Resultado {
	int nota;
	int freq;
	boolean inadimp;
	
	Resultado(int notai, int freqi, boolean inadimpi){
		nota = notai;
		freq=freqi;
		inadimp = inadimpi;

	}

	String calcular(){
		if (nota < 50 || (50 <= nota && nota < 60  && freq >= 75 && inadimp)) {
			return "reprovado";
		} else if ((nota >= 60) && (freq >=75 ) && (inadimp == false)) {
			return "aprovado";
		} else if (inadimp) { 
			return "recuperacao"; 
		} else if ((nota < 60) && (nota >= 50) && (freq >=75 )){
			 return "recuperacao";
		} else 
			return "null"; 
	}
} 

class TestTDD {

	public String calcularresultado(int nota, int freq, boolean inadimp) {
		if ((nota >= 60) && (freq >=75 ) && (inadimp== false)) {
			return "aprovado";
		} else 
			return "null";
	} 
	
	@Test
	void testaaprovado1() {
		int nota = 80;
		int freq = 90;
		boolean inadimp = false;
		Resultado res = new Resultado(nota,freq,inadimp);
		String resultado = res.calcular();
		assertEquals("aprovado",resultado); 
	}
	
	
	@Test
	public void testarecuperacao1() {
		int nota = 80;
		int freq = 90;
		boolean inadimp = true;
		Resultado res = new Resultado(nota,freq,inadimp); 
		String resultado = res.calcular();
		assertEquals("recuperacao",resultado); 
	}
	
	@Test
	public void testarecuperacao2() {
		int nota = 55;
		int freq = 90;
		boolean inadimp = false;
		Resultado res = new Resultado(nota,freq,inadimp);
		String resultado = res.calcular();
		assertEquals("recuperacao",resultado); 
	}
	
	
	@Test
	public void testareprovado1() {
		int nota = 45;
		int freq = 90;
		boolean inadimp = false;
		Resultado res = new Resultado(nota,freq,inadimp);
		String resultado = res.calcular();
		assertEquals("reprovado",resultado);
	 }
	
	@Test
	public void tesareprovado2() {
		int nota = 55;
		int freq = 90;
		boolean inadimp = true;
		Resultado res = new Resultado(nota, freq, inadimp);
		String resultado = res.calcular();
		assertEquals("reprovado", resultado);
	}

}























