//------------------------------------------------------------------------------
// Copyright (c) 2005, 2006 IBM Corporation and others.
// All rights reserved. This program and the accompanying materials
// are made available under the terms of the Eclipse Public License v1.0
// which accompanies this distribution, and is available at
// http://www.eclipse.org/legal/epl-v10.html
// 
// Contributors:
// IBM Corporation - initial implementation
//------------------------------------------------------------------------------

// This file will include dynamically generated process layout related data from 
// the publishing service 
contentPage.processPage.imageFiles["_ld85IcluEeiZSa9vgtvMaA,_4eENwcsTEei4KeV18kH-1gActivity"]="./../../EPF/deliveryprocesses/resources/Validate Build Stability_2B12B874_b6bf30ff_Activity.jpeg"
contentPage.processPage.imageFiles["_ld85IcluEeiZSa9vgtvMaA,_4eENwcsTEei4KeV18kH-1gActivityDetail"]="./../../EPF/deliveryprocesses/resources/Validate Build Stability_2B12B874_b6bf30ff_ActivityDetail.jpeg"
contentPage.processPage.imageFiles["_ld85IcluEeiZSa9vgtvMaAActivity"]="./../../EPF/deliveryprocesses/resources/Config_4745F37_4745f37_Activity.jpeg"
contentPage.processPage.imageFiles["_ld85IcluEeiZSa9vgtvMaA,_qiw20MluEeiZSa9vgtvMaAActivity"]="./../../EPF/deliveryprocesses/resources/Test and Evaluate_5B0A42D8_e6b6bb63_Activity.jpeg"
contentPage.processPage.imageFiles["_ld85IcluEeiZSa9vgtvMaA,_qiw20MluEeiZSa9vgtvMaAActivityDetail"]="./../../EPF/deliveryprocesses/resources/Test and Evaluate_5B0A42D8_e6b6bb63_ActivityDetail.jpeg"
contentPage.processPage.imageFiles["_ld85IcluEeiZSa9vgtvMaA,_mJ_DUcscEei4KeV18kH-1gActivity"]="./../../EPF/deliveryprocesses/resources/Define Evaluation Mission_70FA870D_fca6ff98_Activity.jpeg"
contentPage.processPage.imageFiles["_ld85IcluEeiZSa9vgtvMaA,_mJ_DUcscEei4KeV18kH-1gActivityDetail"]="./../../EPF/deliveryprocesses/resources/Define Evaluation Mission_70FA870D_fca6ff98_ActivityDetail.jpeg"
contentPage.processPage.elementUrls["_AcyeIMlvEeiZSa9vgtvMaA"] = ["Implement Test","EPF/deliveryprocesses/Implement Test_2AB1297B.html"];
contentPage.processPage.elementUrls["__8iQwcluEeiZSa9vgtvMaA"] = ["Test Analyst","EPF/deliveryprocesses/Test Analyst_2C330DD5.html"];
contentPage.processPage.elementUrls["_qG_rccscEei4KeV18kH-1g"] = ["Test Analyst","EPF/deliveryprocesses/Test Analyst_19DE7F66.html"];
contentPage.processPage.elementUrls["__iCm2csTEei4KeV18kH-1g"] = ["Change Request","EPF/deliveryprocesses/Change Request_12F91E73.html"];
contentPage.processPage.elementUrls["_p27PI8scEei4KeV18kH-1g"] = ["Test Automation Architecture","EPF/deliveryprocesses/Test Automation Architecture_8588E567.html"];
contentPage.processPage.elementUrls["_AczFMslvEeiZSa9vgtvMaA"] = ["Build","EPF/deliveryprocesses/Build_362FA61D.html"];
contentPage.processPage.elementUrls["_qG_rcMscEei4KeV18kH-1g"] = ["Identify Targets of Test","EPF/deliveryprocesses/Identify Targets of Test_2B456B50.html"];
contentPage.processPage.elementUrls["__8iQwMluEeiZSa9vgtvMaA"] = ["Determine Test Results","EPF/deliveryprocesses/Determine Test Results_3D99F9BF.html"];
contentPage.processPage.elementUrls["__T6xksluEeiZSa9vgtvMaA"] = ["Change Request","EPF/deliveryprocesses/Change Request_906C5E07.html"];
contentPage.processPage.elementUrls["_p27PIMscEei4KeV18kH-1g"] = ["Agree Mission","EPF/deliveryprocesses/Agree Mission_23781B7C.html"];
contentPage.processPage.elementUrls["__iCm0MsTEei4KeV18kH-1g"] = ["Implement Test","EPF/deliveryprocesses/Implement Test_9B3C461F.html"];
contentPage.processPage.elementUrls["_AczFMMlvEeiZSa9vgtvMaA"] = ["Test Data","EPF/deliveryprocesses/Test Data_3CF8B1F7.html"];
contentPage.processPage.elementUrls["_p27PIcscEei4KeV18kH-1g"] = ["Test Manager","EPF/deliveryprocesses/Test Manager_12112F92.html"];
contentPage.processPage.elementUrls["_mJ_DUcscEei4KeV18kH-1g"] = ["Define Evaluation Mission","EPF/deliveryprocesses/Define Evaluation Mission_70FA870D.html"];
contentPage.processPage.elementUrls["_qX-twMscEei4KeV18kH-1g"] = ["Identify Test Ideas","EPF/deliveryprocesses/Identify Test Ideas_BA8C4841.html"];
contentPage.processPage.elementUrls["_A_L6QcsUEei4KeV18kH-1g"] = ["Test Analyst","EPF/deliveryprocesses/Test Analyst_EDEEFDA9.html"];
contentPage.processPage.elementUrls["_qG_rc8scEei4KeV18kH-1g"] = ["Use-Case Model","EPF/deliveryprocesses/Use-Case Model_8D56353B.html"];
contentPage.processPage.elementUrls["__iCm08sTEei4KeV18kH-1g"] = ["Build","EPF/deliveryprocesses/Build_FD4D100A.html"];
contentPage.processPage.elementUrls["__T6xkMluEeiZSa9vgtvMaA"] = ["Tester","EPF/deliveryprocesses/Tester_973569E1.html"];
contentPage.processPage.elementUrls["_A_L6QMsUEei4KeV18kH-1g"] = ["Determine Test Results","EPF/deliveryprocesses/Determine Test Results_FF55E993.html"];
contentPage.processPage.elementUrls["_qiw20MluEeiZSa9vgtvMaA"] = ["Test and Evaluate","EPF/deliveryprocesses/Test and Evaluate_5B0A42D8.html"];
contentPage.processPage.elementUrls["__T6KgMluEeiZSa9vgtvMaA"] = ["Analyze Test Failure","EPF/deliveryprocesses/Analyze Test Failure_5DFAB278.html"];
contentPage.processPage.elementUrls["_A_L6Q8sUEei4KeV18kH-1g"] = ["Test Results","EPF/deliveryprocesses/Test Results_6166B37E.html"];
contentPage.processPage.elementUrls["_ArC2QcsUEei4KeV18kH-1g"] = ["Test Suite","EPF/deliveryprocesses/Test Suite_81EF25E1.html"];
contentPage.processPage.elementUrls["_APQYcclvEeiZSa9vgtvMaA"] = ["Test-Ideas List","EPF/deliveryprocesses/Test-Ideas List_4B7AE840.html"];
contentPage.processPage.elementUrls["_qX-tw8scEei4KeV18kH-1g"] = ["Design Model","EPF/deliveryprocesses/Design Model_1C9D122C.html"];
contentPage.processPage.elementUrls["_ld85IcluEeiZSa9vgtvMaA"] = ["Config","EPF/deliveryprocesses/Config_4745F37.html"];
contentPage.processPage.elementUrls["_qX-twcscEei4KeV18kH-1g"] = ["Deployment Model","EPF/deliveryprocesses/Deployment Model_A9255C57.html"];
contentPage.processPage.elementUrls["__iCm0csTEei4KeV18kH-1g"] = ["Tester","EPF/deliveryprocesses/Tester_89D55A35.html"];
contentPage.processPage.elementUrls["_qX-txcscEei4KeV18kH-1g"] = ["Test-Ideas List","EPF/deliveryprocesses/Test-Ideas List_6DB73E76.html"];
contentPage.processPage.elementUrls["_AvZREMlvEeiZSa9vgtvMaA"] = ["Verify Changes in Build","EPF/deliveryprocesses/Verify Changes in Build_B785A2BE.html"];
contentPage.processPage.elementUrls["_4eENwcsTEei4KeV18kH-1g"] = ["Validate Build Stability","EPF/deliveryprocesses/Validate Build Stability_2B12B874.html"];
contentPage.processPage.elementUrls["__iCm18sTEei4KeV18kH-1g"] = ["Test-Ideas List","EPF/deliveryprocesses/Test-Ideas List_C1DEF229.html"];
contentPage.processPage.elementUrls["__iCm1csTEei4KeV18kH-1g"] = ["Test Case","EPF/deliveryprocesses/Test Case_4E673C54.html"];
contentPage.processPage.elementUrls["_APQYcMlvEeiZSa9vgtvMaA"] = ["Identify Test Ideas","EPF/deliveryprocesses/Identify Test Ideas_5CE1D42A.html"];
contentPage.processPage.elementUrls["_ArC2QMsUEei4KeV18kH-1g"] = ["Execute Test Suite","EPF/deliveryprocesses/Execute Test Suite_935611CB.html"];
contentPage.processPage.elementUrls["_AvZ4IMlvEeiZSa9vgtvMaA"] = ["Test Results","EPF/deliveryprocesses/Test Results_AFD5B69C.html"];
